## Best of StackOverflow

_I read a lot of StackOverflow. I know the rest of you do. I'm going to get into the weeds and start listing out great answers to specific issues here._

### Machine Learning

- [Similarity between two documents](http://stackoverflow.com/questions/8897593/similarity-between-two-text-documents) (Tf-idf)
