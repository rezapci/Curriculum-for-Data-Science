If you need a quick but comprehensive review on probability and statistics, the following courses from JHU are what you are looking for. A more efficient way maybe starting by doing the exercises before getting sleepy during the video :-)

[Coursera JHU Biostatistics Bootcamp I](https://www.coursera.org/learn/biostatistics/home/welcome)

[Coursera JHU Biostatistics Bootcamp II](https://www.coursera.org/learn/biostatistics-2)

